//
//  CoinModel.swift
//  SloterBoo
//
//  Created by Nirmal on 08/07/24.
//

import Foundation
import CoreData
import UIKit

@available(iOS 13.0, *)
class DataModel:NSObject {
    static let shared = DataModel()
    var managedContext: NSManagedObjectContext!
    let appDelegate = UIApplication.shared.delegate as! AppDelegate
   
    
    func _saveCoinsAndBucks(coins: Int64) {
        managedContext = appDelegate.persistentContainer.viewContext
            let fetchRequest: NSFetchRequest<UserScore> = UserScore.fetchRequest()
            
            do {
                let users = try managedContext.fetch(fetchRequest)
                if let user = users.first {
                    // Update existing user
                    user.coins = coins
                  
                } else {
                    // Create new user
                    let user = UserScore(context: managedContext)
                    user.coins = coins
                   
                }
                
                try managedContext.save()
            } catch {
                print("Failed to save coins and bucks: \(error.localizedDescription)")
            }
        }
    
    func _fetchUserData(_lbl:UILabel) {
        managedContext = appDelegate.persistentContainer.viewContext
            let fetchRequest: NSFetchRequest<UserScore> = UserScore.fetchRequest()
            
            do {
                let users = try managedContext.fetch(fetchRequest)
                if let user = users.first {
                    let coins = user.coins
                   
                    // Update your labels here
                    _lbl.text = "Coins: \(coins)"
                  
                } else {
                    // Handle no user case if needed
                    _lbl.text = "Coins: 0"
                  
                }
            } catch {
                print("Failed to fetch user data: \(error.localizedDescription)")
            }
        }
}
