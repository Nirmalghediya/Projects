//
//  PlayModel.swift
//  SloterBoo
//
//  Created by Nirmal on 08/07/24.
//

import AVFoundation

var audioPlayer: AVAudioPlayer?

public class SoundPlay:NSObject, AVAudioPlayerDelegate
{
    public static let shared = SoundPlay()
    
    
    func Playsound(Resource:String,Type:String) {
        if let path = Bundle.main.path(forResource: Resource, ofType: Type) {
            audioPlayer = AVAudioPlayer()
            let url = URL(fileURLWithPath: path)
            do {
                audioPlayer = try AVAudioPlayer(contentsOf: url)
//                audioPlayer?.numberOfLoops = -1
                audioPlayer?.prepareToPlay()
                audioPlayer?.play()
                audioPlayer?.delegate = self
            } catch {
                print("Error")
            }
        }
    }
    
}
