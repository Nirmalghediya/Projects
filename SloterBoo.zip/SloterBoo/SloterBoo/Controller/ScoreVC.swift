//
//  ScoreVC.swift
//  SloterBoo
//
//  Created by Nirmal on 08/07/24.
//

import UIKit

class ScoreVC: UIViewController {

    @IBOutlet weak var lbl_Coin: UILabel!
    
    var coin = ""
    
    override func viewDidLoad() {
        super.viewDidLoad()
        lbl_Coin.text = coin
        SoundPlay.shared.Playsound(Resource: "Winner", Type: "mp3")
        audioPlayer?.play()
    }
    
    @IBAction func btn_back(_ sender: Any) {
        navigationController?.popViewController(animated: true)
    }
    
}
