//
//  HomeVC.swift
//  SloterBoo
//
//  Created by Nirmal on 08/07/24.
//

import UIKit

@available(iOS 13.0, *)
class HomeVC: UIViewController {
    
    @IBOutlet weak var lbl_Coins: UILabel!
    
    @IBOutlet weak var Switch: UISwitch!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        navigationController?.navigationBar.isHidden = true
        lbl_Coins.DNFont(font: "JotiOne-Regular", size: 18, label: lbl_Coins)
        DataModel.shared._fetchUserData(_lbl: lbl_Coins)
        
        Switch.isOn = true
        if Switch.isOn {
            SoundPlay.shared.Playsound(Resource: "Main", Type: "mp3")
                    audioPlayer?.play()
        }
        else{
            audioPlayer?.stop()
        }
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        DataModel.shared._fetchUserData(_lbl: lbl_Coins)
        if Switch.isOn {
            SoundPlay.shared.Playsound(Resource: "Main", Type: "mp3")
                    audioPlayer?.play()
        }
        else{
            audioPlayer?.stop()
        }
    }
    
    @IBAction func btn_SpinSlot(_ sender: Any) {
        audioPlayer?.stop()
        let currentCoins = self.getCurrentCoins()
        let vc = storyboard?.instantiateViewController(withIdentifier: "SpinVC") as! SpinVC
        vc._points = currentCoins
        navigationController?.pushViewController(vc, animated: true)
    }
    
    @IBAction func btn_blackjack(_ sender: Any) {
        audioPlayer?.stop()
        let vc = storyboard?.instantiateViewController(withIdentifier: "BlackjackVC") as! BlackjackVC
        navigationController?.pushViewController(vc, animated: true)
    }
    
    @IBAction func btn_Setting(_ sender: Any) {
        let vc = storyboard?.instantiateViewController(withIdentifier: "SettingVC") as! SettingVC
        navigationController?.pushViewController(vc, animated: true)
    }
    
    @IBAction func Switch(_ sender: UISwitch) {
        if Switch.isOn {
            SoundPlay.shared.Playsound(Resource: "Main", Type: "mp3")
                    audioPlayer?.play()
        }
        else{
            audioPlayer?.stop()
        }
    }
    
    
    func getCurrentCoins() -> Int64 {
            // Fetch current coins from label or data source
            return Int64(lbl_Coins.text?.components(separatedBy: " ").last ?? "0") ?? 0
        }
    
    func updateLabels() {
        DataModel.shared._fetchUserData(_lbl: lbl_Coins)
        }
    
}

extension UILabel {
    func DNFont(font:String,size:CGFloat,label:UILabel){
        let customFont = UIFont(name: font, size: size)
        label.font = customFont
    }
}
