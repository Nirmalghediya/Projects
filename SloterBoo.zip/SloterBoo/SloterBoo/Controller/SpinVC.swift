//
//  SpinVC.swift
//  SloterBoo
//
//  Created by Nirmal on 08/07/24.
//

import UIKit
import CoreData

@available(iOS 13.0, *)
class SpinVC: UIViewController {

    @IBOutlet weak var lbl_Coin: UILabel!
    
    @IBOutlet weak var lbl_bet: UILabel!
    
    @IBOutlet weak var img_one: UIImageView!
    
    @IBOutlet weak var img_two: UIImageView!
    
    @IBOutlet weak var img_three: UIImageView!
    
    
    var _points:Int64 = 0
        var _bet:Int64 = 100
        var _reel1Result: String?
        var _reel2Result: String?
        var _reel3Result: String?
    var managedContext: NSManagedObjectContext!
    var _images = ["1","2","4","5"]
    
    override func viewDidLoad() {
        super.viewDidLoad()
        updatePointsLabel()
        lbl_Coin.DNFont(font: "JotiOne-Regular", size: 18, label: lbl_Coin)
        lbl_bet.DNFont(font: "JotiOne-Regular", size: 26, label: lbl_bet)
     
    }
    
    @IBAction func btn_back(_ sender: Any) {
        navigationController?.popViewController(animated: true)
    }
    
    @IBAction func btn_spin(_ sender: Any) {
        if _bet < _points  {
            if _points <= 0   {
                showAlert(message: "You no more Coins!")
            }
            else
            {
                if _bet == 0 {
                    showAlert(message: "You no more Coins!")
                }
                else{
                   
                    SoundPlay.shared.Playsound(Resource: "Spin", Type: "mp3")
                    audioPlayer?.play()
                    _spinSlots()
                }
                
            }
        }
        else{
            showAlert(message: "OOp's, You no more Coins!")
        }
    }
    
    @IBAction func btn_plus(_ sender: Any) {
        _bet += 100
        updatePointsLabel()
    }
    
    @IBAction func btn_minus(_ sender: Any) {
        if _bet >= 100 {
            _bet -= 100
            updatePointsLabel()
        }
        else{
            showAlert(message: "Sorry,100 Coins bet is Reqired.")
        }
    }
    
    
    
    func updatePointsLabel() {

        DataModel.shared._fetchUserData(_lbl: lbl_Coin)
        lbl_bet.text = "Bet: \(_bet)"
        }

    func showAlert(message: String) {
        DispatchQueue.main.async {
            let alert = UIAlertController(title: "Coin Status", message: message, preferredStyle: .alert)
            alert.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
            UIApplication.shared.keyWindow?.rootViewController?.present(alert, animated: true, completion: nil)
        }
    }
    
    func _spinSlots() {
           
            _points -= _bet
            updatePointsLabel()
       
        if _points < 0 && _bet < _points {
            showAlert(message: "You no more Coins!")
        } else if  _points < 0 {
            lbl_bet.text = "No Coins!"
        }

            
          
        _animateReel(reel: img_one, completion: {
                self._reel1Result = self._images.randomElement()!
                self.img_one.image = UIImage(named: self._reel1Result!)
            }, delay: 0)
            
        _animateReel(reel: img_two, completion: {
                self._reel2Result = self._images.randomElement()!
                self.img_two.image = UIImage(named: self._reel2Result!)
            }, delay: 0.3)
            
        _animateReel(reel: img_three, completion: {
                self._reel3Result = self._images.randomElement()!
                self.img_three.image = UIImage(named: self._reel3Result!)
                self._checkResults()
            }, delay: 0.6)
        }
    
    func _animateReel(reel: UIImageView, completion: @escaping () -> Void, delay: TimeInterval) {
        let spinCount = 10
        var spinIndex = 0
        
        func spin() {
            UIView.transition(with: reel, duration: 0.1, options: .transitionFlipFromTop, animations: {
                reel.image = UIImage(named: self._images.randomElement()!)
            }, completion: { _ in
                spinIndex += 1
                if spinIndex < spinCount {
                    DispatchQueue.main.asyncAfter(deadline: .now() + 0.1, execute: spin)
                } else {
                    completion()
                }
            })
        }
        
        DispatchQueue.main.asyncAfter(deadline: .now() + delay, execute: spin)
    }
    
    
    func _checkResults() {
        let image1number = _images.firstIndex(of: _reel1Result!)!
        let image2number = _images.firstIndex(of: _reel2Result!)!
        let image3number = _images.firstIndex(of: _reel3Result!)!
        
        audioPlayer?.pause()
     
        if image1number == image2number && image2number == image3number {
            if image1number == 4 {
              
                _points += 4000
      
                let vc = storyboard?.instantiateViewController(withIdentifier: "ScoreVC") as! ScoreVC
                vc.coin = "Coins: \(_points)"
                navigationController?.pushViewController(vc, animated: true)
                
            } else {
                _points += 3000
                _points += 2000
                let vc = storyboard?.instantiateViewController(withIdentifier: "ScoreVC") as! ScoreVC
                vc.coin = "Coins: \(_points)"
                navigationController?.pushViewController(vc, animated: true)
                
            }
        } else if image1number == image2number || image1number == image3number || image2number == image3number {
      
            _points += 2000
            let vc = storyboard?.instantiateViewController(withIdentifier: "ScoreVC") as! ScoreVC
            vc.coin = "Coins: \(_points)"
            navigationController?.pushViewController(vc, animated: true)
           
        } else {
            SoundPlay.shared.Playsound(Resource: "Lose", Type: "mp3")
                        audioPlayer?.play()
        }
        DataModel.shared._saveCoinsAndBucks(coins: _points)
                updatePointsLabel()
    }
    

}
