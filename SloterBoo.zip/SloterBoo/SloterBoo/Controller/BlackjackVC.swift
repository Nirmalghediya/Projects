//
//  BlackjackVC.swift
//  SloterBoo
//
//  Created by Nirmal on 08/07/24.
//

import UIKit

@available(iOS 13.0, *)
class BlackjackVC: UIViewController {

    @IBOutlet weak var imgone: UIImageView!
    
    @IBOutlet weak var imgtwo: UIImageView!
    
    @IBOutlet weak var imgthree: UIImageView!
    
    @IBOutlet weak var imgfour: UIImageView!
    
    @IBOutlet weak var btn_hit: UIButton!
    
    @IBOutlet weak var btn_stand: UIButton!
    
    @IBOutlet weak var lbl_Coins: UILabel!
    
    @IBOutlet weak var lbl_head: UILabel!
    
    @IBOutlet weak var lbl_Result: UILabel!
    
    
    @IBOutlet weak var btn_restart: UIButton!
    
    let deck: [String] = ["2", "3", "4", "5", "6", "7", "8", "9", "10", "J", "Q", "K", "A"]
    var randomCardSelction = ""
    var playerCards: [String] = []
    var dealerCards: [String] = []
    var playerScore: Int = 0
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.randomCardSelction = ["♠","♣","♥","♦"].randomElement()!
        startNewGame()
        lbl_Coins.DNFont(font: "JotiOne-Regular", size: 18, label: lbl_Coins)
        btn_restart.isHidden = true
        lbl_Result.DNFont(font: "JotiOne-Regular", size: 28, label: lbl_Result)
    }
    
    @IBAction func btn_back(_ sender: Any) {
        navigationController?.popViewController(animated: true)
    }
    
    @IBAction func btn_hit(_ sender: Any) {
        imgfour.image = UIImage(named: "\(dealerCards[1])\(randomCardSelction)")
        
        let dealerScore = _calculateScore(for: dealerCards)
        if playerScore > dealerScore || dealerScore > 21 {
            lbl_Result.text = "You Win!"
        } else {
            lbl_Result.text = "You Lose!"
        }
        btn_restart.isHidden = false
    }
    
    @IBAction func btn_stand(_ sender: Any) {
        imgfour.image = UIImage(named: "\(dealerCards[1])\(randomCardSelction)")
        
        let dealerScore = _calculateScore(for: dealerCards)
        if playerScore > dealerScore || dealerScore > 21 {
            lbl_Result.text = "You Win!"
            
        } else {
            lbl_Result.text = "You Lose!"
            
        }
        btn_restart.isHidden = false
    }
    
    @IBAction func btn_restart(_ sender: Any) {
        btn_restart.isHidden = true
        startNewGame()
    }
    
    func startNewGame() {
        playerCards = [_drawRandomCard(), _drawRandomCard()]
        dealerCards = [_drawRandomCard(), _drawRandomCard()]
        _refreshUI()
        updatePlayerScore()
    }
    
    func _drawRandomCard() -> String {
        return deck.randomElement()!
    }
    
    func _refreshUI() {
        imgone.image = UIImage(named: "\(playerCards[0])\(randomCardSelction)")
        imgtwo.image = UIImage(named: "\(playerCards[1])\(randomCardSelction)")
        imgthree.image = UIImage(named: "\(dealerCards[0])\(randomCardSelction)")
        imgfour.image = UIImage(named: "Pattu")
    }
    
    func _calculateScore(for cards: [String]) -> Int {
        var score = 0
        var acesCount = 0
        for card in cards {
            switch card {
            case "2", "3", "4", "5", "6", "7", "8", "9", "10":
                score += Int(card)!
            case "J", "Q", "K":
                score += 10
            case "A":
                acesCount += 1
                score += 11
            default:
                break
            }
        }
        while score > 21 && acesCount > 0 {
            score -= 10
            acesCount -= 1
        }
        return score
    }
    
    func displayAlert(withTitle title: String, message: String) {
        let alert = UIAlertController(title: title, message: message, preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "OK", style: .default, handler: { _ in
            self.startNewGame()
        }))
        present(alert, animated: true, completion: nil)
    }
    
    func updatePlayerScore() {
        playerScore = _calculateScore(for: playerCards)
        lbl_Coins.text = "Score: \(playerScore)"
        print(playerScore)
    }
   
    @IBAction func btn_help(_ sender: Any) {
        let vc = storyboard?.instantiateViewController(withIdentifier: "HelpVC") as! HelpVC
        navigationController?.pushViewController(vc, animated: true)
    }
    
    
  
}
// lbl_Coins.DNFont(font: "JotiOne-Regular", size: 18, label: lbl_Coins)
