//
//  HelpVC.swift
//  SloterBoo
//
//  Created by Nirmal on 10/07/24.
//

import UIKit

class HelpVC: UIViewController {

    @IBOutlet weak var lbl_details: UILabel!
    
    @IBOutlet weak var lbl_head: UILabel!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        lbl_details.DNFont(font: "JotiOne-Regular", size: 30, label: lbl_details)
        lbl_head.DNFont(font: "JotiOne-Regular", size: 30, label: lbl_head)
       
    }
    
    @IBAction func btn_back(_ sender: Any) {
        navigationController?.popViewController(animated: true)
    }
    
   

}
