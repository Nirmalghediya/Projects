//
//  CardModel.swift
//  JestSloter
//
//  Created by Nirmal on 19/07/24.
//

import Foundation
import UIKit

struct Card {
    var suit: String
    var rank: String
    
    var imageName: String {
        return "\(rank)\(suit)"
    }
}

class Deck {
    var cards: [Card] = []
    
    init() {
        resetDeck()
    }
    
    func resetDeck() {
        let suits = ["♠", "♣", "♥", "♦"]
        let ranks = ["2", "3", "4", "5", "6", "7", "8", "9", "10", "J", "Q", "K", "A"]
        
        cards = []
        for suit in suits {
            for rank in ranks {
                cards.append(Card(suit: suit, rank: rank))
            }
        }
        
        shuffle()
    }
    
    func shuffle() {
        cards.shuffle()
    }
    
    func deal() -> Card? {
        if cards.isEmpty {
            resetDeck()
        }
        return cards.isEmpty ? nil : cards.removeFirst()
    }
}
