//
//  Player.swift
//  JestSloter
//
//  Created by Nirmal on 19/07/24.
//

import Foundation
import AVFAudio
var audioPlayer: AVAudioPlayer?

public class SoundPlay:NSObject, AVAudioPlayerDelegate
{
    public static let shared = SoundPlay()
    
    
    func Playsound(Resource:String,Type:String) {
        if let path = Bundle.main.path(forResource: Resource, ofType: Type) {
            audioPlayer = AVAudioPlayer()
            let url = URL(fileURLWithPath: path)
            do {
                audioPlayer = try AVAudioPlayer(contentsOf: url)
                audioPlayer?.numberOfLoops = -1
                audioPlayer?.prepareToPlay()
                audioPlayer?.play()
                audioPlayer?.delegate = self
            } catch {
                print("Error")
            }
        }
    }
    
}
