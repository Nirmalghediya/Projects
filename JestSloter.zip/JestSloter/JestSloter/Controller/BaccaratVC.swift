//
//  BaccaratVC.swift
//  JestSloter
//
//  Created by Nirmal on 19/07/24.
//

import UIKit
import CoreData

@available(iOS 13.0, *)
class BaccaratVC: UIViewController {

    @IBOutlet weak var img_one: UIImageView!
    
    @IBOutlet weak var img_two: UIImageView!
    
    @IBOutlet weak var img_three: UIImageView!
    
    @IBOutlet weak var img_four: UIImageView!
    
    @IBOutlet weak var lbl_bet: UILabel!
    
    @IBOutlet weak var img_coins: UILabel!
    
    @IBOutlet weak var lbl_result: UILabel!
    
    var deck = Deck()
    var _points:Int64 = 0
        var _bet:Int64 = 100
    var managedContext: NSManagedObjectContext!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        lbl_result.text = ""
        updatePointsLabel()
    }
    
    @IBAction func btn_back(_ sender: Any) {
        navigationController?.popViewController(animated: true)
    }
    
    @IBAction func btn_clear(_ sender: Any) {
        _bet = 100
        updatePointsLabel()
    }
    
    @IBAction func btn_double(_ sender: Any) {
        _bet = _bet * 2
        updatePointsLabel()
    }
    
    @IBAction func btn_draw(_ sender: Any) {
        guard let playerCard1 = deck.deal(),
                      let playerCard2 = deck.deal(),
                      let bankerCard1 = deck.deal(),
                      let bankerCard2 = deck.deal() else {
                    lbl_bet.text = "Deck is empty. Resetting deck..."
                    deck.resetDeck()
                    return
                }
                
                img_three.image = UIImage(named: playerCard1.imageName)
                img_four.image = UIImage(named: playerCard2.imageName)
                img_one.image = UIImage(named: bankerCard1.imageName)
                img_two.image = UIImage(named: bankerCard2.imageName)
                
                let playerCards = [playerCard1, playerCard2]
                let bankerCards = [bankerCard1, bankerCard2]
                
                let result = determineWinner(playerCards: playerCards, bankerCards: bankerCards)
        lbl_result.text = result
        _points -= _bet
        print("Points: \(_points) and Bet: \(_bet)")
        DataModel.shared._saveCoinsAndBucks(coins: _points)
        updatePointsLabel()
        print("Points: \(_points) and Bet: \(_bet)")
    }
    
    @IBAction func btn_help(_ sender: Any) {
        let vc = storyboard?.instantiateViewController(withIdentifier: "HelpVC") as! HelpVC
        navigationController?.pushViewController(vc, animated: true)
    }
    
    
    func calculateHandValue(cards: [Card]) -> Int {
     
            var value = 0
            for card in cards {
                if let intValue = Int(card.rank) {
                    value += intValue
                } else if card.rank == "A" {
                    value += 1
                } else {
                    value += 10
                }
            }
            return value % 10
        }
        
        func determineWinner(playerCards: [Card], bankerCards: [Card]) -> String {
            updatePointsLabel()
            let playerValue = calculateHandValue(cards: playerCards)
            let bankerValue = calculateHandValue(cards: bankerCards)
            
            if playerValue > bankerValue {
            _points += 2000
                DataModel.shared._saveCoinsAndBucks(coins: _points)
                updatePointsLabel()
                
                let vc = storyboard?.instantiateViewController(withIdentifier: "ScoreVC") as! ScoreVC
                vc.coin = "Coins: \(_points)"
                navigationController?.pushViewController(vc, animated: true)
                
                return "You Wins"
            } else if playerValue < bankerValue {
                return "Computer Wins"
            } else {
                _points += _bet * 2
                    DataModel.shared._saveCoinsAndBucks(coins: _points)
                    updatePointsLabel()
                return "Tie"
            }
            
        }
    
    func updatePointsLabel() {

        DataModel.shared._fetchUserData(_lbl: img_coins)
        lbl_bet.text = "Bet: \(_bet)"
        }


}
