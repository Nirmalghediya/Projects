//
//  ScoreVC.swift
//  JestSloter
//
//  Created by Nirmal on 19/07/24.
//

import UIKit

class ScoreVC: UIViewController {

    @IBOutlet weak var btn_coin: UILabel!
    
    var coin = ""
    
    override func viewDidLoad() {
        super.viewDidLoad()
        SoundPlay.shared.Playsound(Resource: "Winner", Type: "mp3")
        audioPlayer?.play()
        btn_coin.text = coin
    }
    
    @IBAction func btn_back(_ sender: Any) {
        audioPlayer?.stop()
        navigationController?.popViewController(animated: true)
    }
    

}
