//
//  HelpVC.swift
//  JestSloter
//
//  Created by Nirmal on 19/07/24.
//

import UIKit

class HelpVC: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

      
    }
    
    @IBAction func btn_back(_ sender: Any) {
        navigationController?.popViewController(animated: true)
    }
    

}
