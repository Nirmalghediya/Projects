//
//  HomeVC.swift
//  JestSloter
//
//  Created by Nirmal on 19/07/24.
//

import UIKit

@available(iOS 13.0, *)
class HomeVC: UIViewController {

    @IBOutlet weak var lbl_coin: UILabel!
    
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        DataModel.shared._fetchUserData(_lbl: lbl_coin)
        navigationController?.navigationBar.isHidden = true
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        DataModel.shared._fetchUserData(_lbl: lbl_coin)
    }
   
    @IBAction func btn_spin(_ sender: Any) {
        let currentCoins = self.getCurrentCoins()
        let vc = storyboard?.instantiateViewController(withIdentifier: "SpinVC") as! SpinVC
       vc._points = currentCoins
        navigationController?.pushViewController(vc, animated: true)
    }
    
    @IBAction func btn_baccarat(_ sender: Any) {
        let currentCoins = self.getCurrentCoins()
        let vc = storyboard?.instantiateViewController(withIdentifier: "BaccaratVC") as! BaccaratVC
        vc._points = currentCoins
        navigationController?.pushViewController(vc, animated: true)
    }
    
    
    @IBAction func btn_setting(_ sender: Any) {
        let vc = storyboard?.instantiateViewController(withIdentifier: "SettingVC") as! SettingVC
        navigationController?.pushViewController(vc, animated: true)
    }
    
    func getCurrentCoins() -> Int64 {
            // Fetch current coins from label or data source
            return Int64(lbl_coin.text?.components(separatedBy: " ").last ?? "0") ?? 0
        }
    
    func updateLabels() {
        DataModel.shared._fetchUserData(_lbl: lbl_coin)
        }

}
