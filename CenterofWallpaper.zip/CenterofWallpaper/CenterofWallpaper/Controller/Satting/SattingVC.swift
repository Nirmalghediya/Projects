//
//  SattingVC.swift
//  CenterofWallpaper
//
//  Created by Nirmal on 03/07/24.
//

import UIKit
import StoreKit

class SattingVC: UIViewController,SKStoreProductViewControllerDelegate {

    override func viewDidLoad() {
        super.viewDidLoad()
        navigationController?.navigationBar.isHidden = true
       
    }
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        tabBarController?.tabBar.isHidden = false
    }
    
    @IBAction func btn_more(_ sender: Any) {
        moreApps(from: self)
    }
    
    @IBAction func btn_share(_ sender: Any) {
        let appURL = URL(string: "https://apps.apple.com/us/app/your-app-id")!
        let shareText = "Check out this amazing app!"
        
        let activityViewController = UIActivityViewController(activityItems: [shareText, appURL], applicationActivities: nil)
        
        // For iPads, present as a popover
        if let popoverController = activityViewController.popoverPresentationController {
            popoverController.sourceView = self.view
            popoverController.sourceRect = CGRect(x: self.view.bounds.midX, y: self.view.bounds.midY, width: 0, height: 0)
            popoverController.permittedArrowDirections = []
        }
        
        self.present(activityViewController, animated: true, completion: nil)
    }
    
    @IBAction func btn_rate(_ sender: Any) {
        if #available(iOS 10.3, *) {
                   SKStoreReviewController.requestReview()
               } else if let url = URL(string: "itms-apps://itunes.apple.com/app/" + "appId") {
                   if #available(iOS 10, *) {
                       UIApplication.shared.open(url, options: [:], completionHandler: nil)
                   } else {
                       UIApplication.shared.openURL(url)
                   }
               }
    }
    
    func moreApps(from viewController: UIViewController) {
            let alert = UIAlertController(title: "More Apps", message: "This feature will be available once the app is live.", preferredStyle: .alert)
            alert.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
            viewController.present(alert, animated: true, completion: nil)
        }
    
    func productViewControllerDidFinish(_ viewController: SKStoreProductViewController) {
            viewController.dismiss(animated: true, completion: nil)
        }

}
