//
//  PreviewVC.swift
//  CenterofWallpaper
//
//  Created by Nirmal on 03/07/24.
//

import UIKit

class PreviewVC: UIViewController {

    @IBOutlet weak var img_Wallpaper: UIImageView!
    
    var image = UIImage()
    var drawingList: [ImageModel]?
    var drawingId: String?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        tabBarController?.tabBar.isHidden = true
        img_Wallpaper.image = image
      
    }
    
    @IBAction func btn_back(_ sender: Any) {
        navigationController?.popViewController(animated: true)
    }
    
    @IBAction func btn_save(_ sender: Any) {
        let alert = UIAlertController(title: "Download WallPaper", message: "Wallpaper Download Successfully.", preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "OK", style: .default))
        present(alert, animated: true)
        if let selectedImage = img_Wallpaper.image {
                saveImageToPhotoLibrary(image: selectedImage)
            }
    }
    
    @IBAction func btn_share(_ sender: UIButton) {
        guard let image = img_Wallpaper.image else {
            print("Image not found!")
            return
        }

        let activityViewController = UIActivityViewController(activityItems: [image], applicationActivities: nil)

        // For iPads: to prevent crash on iPads
        if let popoverController = activityViewController.popoverPresentationController {
            popoverController.sourceView = sender
            popoverController.sourceRect = sender.bounds
        }

        present(activityViewController, animated: true, completion: nil)
    }
    
    @IBAction func btn_fav(_ sender: Any) {
        let userDefaults = UserDefaults.standard
        if userDefaults.object(forKey: "savedDrawings") != nil {
            let decoded  = userDefaults.data(forKey: "savedDrawings")
            do {
                let list = try JSONDecoder().decode([ImageModel].self, from: decoded!)
                drawingList = list
            } catch let error {
                let alert = UIAlertController(title: "Error saving File Try again", message: "\(error.localizedDescription)", preferredStyle: UIAlertController.Style.alert)
                alert.addAction(UIAlertAction(title: "Ok", style: UIAlertAction.Style.default, handler: nil))
                self.present(alert, animated: true, completion: nil)
                print("Error \(error.localizedDescription)")
            }
        } else {
            drawingList = [ImageModel]()
        }
        
        let img = img_Wallpaper.image!
        guard let data = img.pngData() else {
            // Show alert error saving drawing.
            return
        }
        

        
        if let row = drawingList!.firstIndex(where: {$0.id == drawingId}) {
            drawingList![row] = ImageModel(data: data, id: drawingId ?? "")
        }
        
        if !drawingList!.contains(where: { $0.id == drawingId ?? ""}) {
            drawingList?.append(ImageModel(data: data, id: UUID().uuidString))
        }
        
        do {
            let encodeData = try JSONEncoder().encode(drawingList!)
                UserDefaults.standard.set(encodeData, forKey: "savedDrawings")
            let alert = UIAlertController(title: "Liked", message: "Wallpaper Liked", preferredStyle: UIAlertController.Style.alert)
            alert.addAction(UIAlertAction(title: "Ok", style: UIAlertAction.Style.default,handler: { action in
               
            }))
            self.present(alert, animated: true, completion: nil)
            
        } catch let error {
            let alert = UIAlertController(title: "Error saving File Try again", message: "\(error.localizedDescription)", preferredStyle: UIAlertController.Style.alert)
            alert.addAction(UIAlertAction(title: "Ok", style: UIAlertAction.Style.default, handler: nil))
            self.present(alert, animated: true, completion: nil)
            print("Error \(error.localizedDescription)")
        }
    }
    
    //MARK: Download Wallpaper
    func saveImageToPhotoLibrary(image: UIImage) {
        UIImageWriteToSavedPhotosAlbum(image, nil, nil, nil)
    }

}
