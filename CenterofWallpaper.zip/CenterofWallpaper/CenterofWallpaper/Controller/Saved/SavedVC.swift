//
//  SavedVC.swift
//  CenterofWallpaper
//
//  Created by Nirmal on 03/07/24.
//

import UIKit

class SavedVC: UIViewController {

    @IBOutlet weak var WallpaperCollectionView: UICollectionView!
    
    var drawingList: [ImageModel]?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        navigationController?.navigationBar.isHidden = true
        WallpaperCollectionView.delegate = self
        WallpaperCollectionView.dataSource = self
        WallpaperCollectionView.register(UINib(nibName: "WallpaperCVCell", bundle: nil), forCellWithReuseIdentifier: "WallpaperCVCell")
    }
  
    override func viewWillAppear(_ animated: Bool) {
        tabBarController?.tabBar.isHidden = false
        print("is hidden \(UserDefaults.standard.object(forKey: "savedDrawings") == nil)")
        
        WallpaperCollectionView.isHidden = UserDefaults.standard.object(forKey: "savedDrawings") == nil
        
        if UserDefaults.standard.object(forKey: "savedDrawings") != nil {
            let decoded  = UserDefaults.standard.data(forKey: "savedDrawings")
            do {
                let list = try JSONDecoder().decode([ImageModel].self, from: decoded!)
                drawingList = list
                WallpaperCollectionView.reloadData()
            } catch let error {
                let alert = UIAlertController(title: "Error getting drawings", message: "error.localizedDescription", preferredStyle: UIAlertController.Style.alert)
                alert.addAction(UIAlertAction(title: "Ok", style: UIAlertAction.Style.default, handler: nil))
                self.present(alert, animated: true, completion: nil)
                print("Error \(error.localizedDescription)")
            }
        }
    }
    
}

extension SavedVC:UICollectionViewDelegate,UICollectionViewDataSource {
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        if drawingList?.count != 0 {
            return drawingList?.count ?? 0
        }
        return 0
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
      
            let cell = WallpaperCollectionView.dequeueReusableCell(withReuseIdentifier: "WallpaperCVCell", for: indexPath) as! WallpaperCVCell
            cell.img_wallpaper.image = UIImage(data: drawingList![indexPath.row].data)
            return cell
        
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        let selectedCell = collectionView.cellForItem(at: indexPath) as! WallpaperCVCell
        let vc = storyboard?.instantiateViewController(withIdentifier: "PreviewVC") as! PreviewVC
        vc.image = selectedCell.img_wallpaper.image!
        navigationController?.pushViewController(vc, animated: true)
    }
    
    
}

extension SavedVC:UICollectionViewDelegateFlowLayout
{
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
       
            let flowayout = collectionViewLayout as? UICollectionViewFlowLayout
            let space: CGFloat = (flowayout?.minimumInteritemSpacing ?? 0.0) + (flowayout?.sectionInset.left ?? 0.0) + (flowayout?.sectionInset.right ?? 0.0)
            let size:CGFloat = (collectionView.frame.size.width - space) / 2.0
           return CGSize(width: size, height: size * 1.3)
        }
}
