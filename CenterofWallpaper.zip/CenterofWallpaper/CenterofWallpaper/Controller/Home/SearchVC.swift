//
//  SearchVC.swift
//  CenterofWallpaper
//
//  Created by Nirmal on 03/07/24.
//

import UIKit

class SearchVC: UIViewController {

    @IBOutlet weak var txt_Searc: UITextField!
    
    @IBOutlet weak var Search_View: UIView!
    
    @IBOutlet weak var WallpaperCollectionView: UICollectionView!
    
    
    var photos: [Photo] = []
    
    override func viewDidLoad() {
        super.viewDidLoad()
        Search_View.layer.cornerRadius = 10
        LoadData(Search: "ocean")
        WallpaperCollectionView.delegate = self
        WallpaperCollectionView.dataSource = self
        WallpaperCollectionView.register(UINib(nibName: "WallpaperCVCell", bundle: nil), forCellWithReuseIdentifier: "WallpaperCVCell")
        txt_Searc.delegate = self
        tabBarController?.tabBar.isHidden = true
    
    }
    
    @IBAction func btn_back(_ sender: Any) {
        navigationController?.popViewController(animated: true)
    }
    
    
    @IBAction func txt_Search(_ sender: UITextField) {
        let Search = txt_Searc.text
        NetworkManager.shared.fetchNatureImages(query: Search!) { [weak self] result in
            DispatchQueue.main.async {
                switch result {
                case .success(let photos):
                    self?.photos = photos
                    self?.WallpaperCollectionView.reloadData()
                case .failure(let error):
                    print("Failed to fetch photos: \(error)")
                }
            }
        }
    }
    
    func LoadData(Search:String){
        NetworkManager.shared.fetchNatureImages(query: Search) { [weak self] result in
                    DispatchQueue.main.async {
                        switch result {
                        case .success(let photos):
                            self?.photos = photos
                            self?.WallpaperCollectionView.reloadData()
                        case .failure(let error):
                            print("Failed to fetch photos: \(error)")
                        }
                    }
                }
    }
    
}

extension SearchVC:UICollectionViewDelegate,UICollectionViewDataSource {
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
       
            return photos.count
       
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
      
            let cell = WallpaperCollectionView.dequeueReusableCell(withReuseIdentifier: "WallpaperCVCell", for: indexPath) as! WallpaperCVCell
            let photo = photos[indexPath.item]
        cell.img_wallpaper.kf.setImage(with: URL(string: photo.src.medium),placeholder: UIImage(named: "placeholder"))
                
                return cell
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        let selectedCell = collectionView.cellForItem(at: indexPath) as! WallpaperCVCell
        let vc = storyboard?.instantiateViewController(withIdentifier: "PreviewVC") as! PreviewVC
        vc.image = selectedCell.img_wallpaper.image!
        navigationController?.pushViewController(vc, animated: true)
    }
}

extension SearchVC:UITextFieldDelegate
{
    func textField(_ textField: UITextField, shouldChangeCharactersIn range: NSRange, replacementString string: String) -> Bool {
        guard let searchText = (textField.text as NSString?)?.replacingCharacters(in: range, with: string) else {
            return true
        }
        // Perform search based on the searchText
        print("Search text: \(searchText)")
    
        DispatchQueue.main.async {
            NetworkManager.shared.fetchNatureImages(query: searchText) { [weak self] result in
                DispatchQueue.main.async {
                    switch result {
                    case .success(let photos):
                        self?.photos = photos
                        self?.WallpaperCollectionView.reloadData()
                    case .failure(let error):
                        print("Failed to fetch photos: \(error)")
                    }
                }
            }
        }
        return true
    }
}

extension SearchVC:UICollectionViewDelegateFlowLayout
{
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
       
            let flowayout = collectionViewLayout as? UICollectionViewFlowLayout
            let space: CGFloat = (flowayout?.minimumInteritemSpacing ?? 0.0) + (flowayout?.sectionInset.left ?? 0.0) + (flowayout?.sectionInset.right ?? 0.0)
            let size:CGFloat = (collectionView.frame.size.width - space) / 2.0
           return CGSize(width: size, height: size * 1.3)
        }
}
