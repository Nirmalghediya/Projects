//
//  HomeVC.swift
//  CenterofWallpaper
//
//  Created by Nirmal on 03/07/24.
//

import UIKit

class HomeVC: UIViewController {

    @IBOutlet weak var Search_View: UIView!
    
    @IBOutlet weak var CategotyCollectionView: UICollectionView!
    
    @IBOutlet weak var WallpaperCollectionView: UICollectionView!
    
    var photos: [Photo] = []
    let Categorys = Category().Category
    
    override func viewDidLoad() {
        super.viewDidLoad()
        navigationController?.navigationBar.isHidden = true
        CategotyCollectionView.delegate = self
        CategotyCollectionView.dataSource = self
        CategotyCollectionView.register(UINib(nibName: "CategoryCVCell", bundle: nil), forCellWithReuseIdentifier: "CategoryCVCell")
        
        WallpaperCollectionView.delegate = self
        WallpaperCollectionView.dataSource = self
        WallpaperCollectionView.register(UINib(nibName: "WallpaperCVCell", bundle: nil), forCellWithReuseIdentifier: "WallpaperCVCell")
        
        Search_View.layer.cornerRadius = 25
      
        let tapGesture = UITapGestureRecognizer(target: self, action: #selector(Search(_:)))
        Search_View.addGestureRecognizer(tapGesture)
        
        LoadWallpaper()
      
    }
    
    @objc func Search(_ sender: UITapGestureRecognizer) {
        // Action to be performed on tap
        let vc = storyboard?.instantiateViewController(withIdentifier: "SearchVC") as! SearchVC
        navigationController?.pushViewController(vc, animated: true)
    }
    
    func LoadWallpaper(){
        NetworkManager.shared.fetchNatureImages(query: "Wallpaper") { [weak self] result in
                    DispatchQueue.main.async {
                        switch result {
                        case .success(let photos):
                            self?.photos = photos
                            self?.WallpaperCollectionView.reloadData()
                        case .failure(let error):
                            print("Failed to fetch photos: \(error)")
                        }
                    }
                }
    }
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        tabBarController?.tabBar.isHidden = false
    }
   
  
}

extension HomeVC:UICollectionViewDelegate,UICollectionViewDataSource {
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        if collectionView == CategotyCollectionView {
            return Categorys.count
        }
        else if collectionView == WallpaperCollectionView
        {
            return photos.count
        }
        else {
            return photos.count
        }
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        if collectionView == CategotyCollectionView {
            let cell = CategotyCollectionView.dequeueReusableCell(withReuseIdentifier: "CategoryCVCell", for: indexPath) as! CategoryCVCell
            cell.img_categoty.image = UIImage(named: Categorys[indexPath.row])
            cell.lbl_categoty.text = Categorys[indexPath.row]
            return cell
        }
        else {
            let cell = WallpaperCollectionView.dequeueReusableCell(withReuseIdentifier: "WallpaperCVCell", for: indexPath) as! WallpaperCVCell
            let photo = photos[indexPath.item]
            cell.img_wallpaper.kf.setImage(with: URL(string: photo.src.medium),placeholder: UIImage(named: "placeholder"))
            return cell
        }
       
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        if collectionView == CategotyCollectionView {
            NetworkManager.shared.fetchNatureImages(query: Categorys[indexPath.row]) { [weak self] result in
                        DispatchQueue.main.async {
                            switch result {
                            case .success(let photos):
                                self?.photos = photos
                                self?.WallpaperCollectionView.reloadData()
                            case .failure(let error):
                                print("Failed to fetch photos: \(error)")
                            }
                        }
                    }
        }
        else {
            let selectedCell = collectionView.cellForItem(at: indexPath) as! WallpaperCVCell
            let vc = storyboard?.instantiateViewController(withIdentifier: "PreviewVC") as! PreviewVC
            vc.image = selectedCell.img_wallpaper.image!
            navigationController?.pushViewController(vc, animated: true)
        }
    }
    
    
}

extension HomeVC:UICollectionViewDelegateFlowLayout
{
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        if collectionView == CategotyCollectionView {
            return CGSize(width: 150, height: 120)
        }
        else
        {
            let flowayout = collectionViewLayout as? UICollectionViewFlowLayout
            let space: CGFloat = (flowayout?.minimumInteritemSpacing ?? 0.0) + (flowayout?.sectionInset.left ?? 0.0) + (flowayout?.sectionInset.right ?? 0.0)
            let size:CGFloat = (collectionView.frame.size.width - space) / 2.0
           return CGSize(width: size, height: size * 1.3)
        }
         }
        
        
        
        
    }

/*
 let flowayout = collectionViewLayout as? UICollectionViewFlowLayout
 let space: CGFloat = (flowayout?.minimumInteritemSpacing ?? 0.0) + (flowayout?.sectionInset.left ?? 0.0) + (flowayout?.sectionInset.right ?? 0.0)
 let size:CGFloat = (collectionView.frame.size.width - space) / 3.4
return CGSize(width: size, height: size * 1.3)
 */
