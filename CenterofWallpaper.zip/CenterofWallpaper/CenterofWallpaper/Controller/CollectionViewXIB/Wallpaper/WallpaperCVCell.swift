//
//  WallpaperCVCell.swift
//  CenterofWallpaper
//
//  Created by Nirmal on 03/07/24.
//

import UIKit

class WallpaperCVCell: UICollectionViewCell {

    @IBOutlet weak var img_wallpaper: UIImageView!
    
    
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

}
