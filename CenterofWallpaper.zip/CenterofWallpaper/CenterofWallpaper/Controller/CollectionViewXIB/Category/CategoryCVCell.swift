//
//  CategoryCVCell.swift
//  CenterofWallpaper
//
//  Created by Nirmal on 03/07/24.
//

import UIKit

class CategoryCVCell: UICollectionViewCell {

    @IBOutlet weak var img_categoty: UIImageView!
    
    @IBOutlet weak var lbl_categoty: UILabel!
    
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

}
