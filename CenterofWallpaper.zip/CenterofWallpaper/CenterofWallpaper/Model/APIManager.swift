//
//  APIManager.swift
//  CenterofWallpaper
//
//  Created by Nirmal on 03/07/24.
//

import Foundation


class NetworkManager {
    static let shared = NetworkManager()
    private init() {}

    let apiKey = "JxEtlKnkHpcVwyLsgGSfzYUJ8SEWLXbALB8nX49vFonfArXSkZ1XAyGX"
    

    func fetchNatureImages(query:String,completion: @escaping (Result<[Photo], Error>) -> Void) {
        let baseUrl = "https://api.pexels.com/v1/search?query=\(query)&per_page=80"
        guard let url = URL(string: baseUrl) else { return }

        var request = URLRequest(url: url)
        request.setValue(apiKey, forHTTPHeaderField: "Authorization")

        let task = URLSession.shared.dataTask(with: request) { data, response, error in
            if let error = error {
                completion(.failure(error))
                return
            }

            guard let data = data else { return }

            do {
                let response = try JSONDecoder().decode(PexelsResponse.self, from: data)
                completion(.success(response.photos))
            } catch {
                completion(.failure(error))
            }
        }
        task.resume()
    }
}
