//
//  DataModel.swift
//  CenterofWallpaper
//
//  Created by Nirmal on 03/07/24.
//

import Foundation

struct Category {
    var Category = ["Abstract","Aesthetic","Nature","Colorful","Minimal","Texture","Space","Plants","Interior","Tech","Art","Architech"]
}

struct ImageModel: Codable {
    let data: Data
    let id: String
}

struct PexelsResponse: Codable {
    let photos: [Photo]
}

struct Photo: Codable {
    let id: Int
    let url: String
    let src: Src
}

struct Src: Codable {
    let medium: String
}
