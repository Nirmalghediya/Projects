//
//  APIManager.swift
//  FoxPasswordGenerator
//
//  Created by Nirmal on 24/05/24.
//

import Foundation
class APIManager {
    static let shared = APIManager()
   

    private init() {}

    // Define the function to call the API
    func generatePassword(length: Int, completion: @escaping (String?) -> Void) {
        // Base URL with the query parameter for length
        let urlString = "https://api.api-ninjas.com/v1/passwordgenerator?length=\(length)"
        
        // Ensure the URL is valid
        guard let url = URL(string: urlString) else {
            print("Invalid URL")
            completion(nil)
            return
        }
        
        // Create the URL request
        var request = URLRequest(url: url)
        // Set the API key in the request header
        request.setValue("A6KAwIWeyu3ss4L2QSDwTBHDnthzP0XAgPG8lTa5", forHTTPHeaderField: "X-Api-Key")
        
        // Create a URLSession data task
        let task = URLSession.shared.dataTask(with: request) { data, response, error in
            // Handle error
            if let error = error {
                print("Error making API call: \(error.localizedDescription)")
                completion(nil)
                return
            }
            
            // Ensure we have valid data
            guard let data = data else {
                print("No data received")
                completion(nil)
                return
            }
            
            // Print the raw response data for debugging
            if let rawResponse = String(data: data, encoding: .utf8) {
               // print("Raw response: \(rawResponse)")
            }
            
            // Parse the JSON response
            do {
                if let json = try JSONSerialization.jsonObject(with: data, options: []) as? [String: Any] {
                    //print("JSON response: \(json)")
                    if let password = json["random_password"] as? String {
                        // Return the generated password
                        completion(password)
                    } else {
                        print("Password not found in JSON response")
                        completion(nil)
                    }
                } else {
                    print("Invalid JSON structure")
                    completion(nil)
                }
            } catch {
                print("Error parsing JSON: \(error.localizedDescription)")
                completion(nil)
            }
        }
        
        // Start the task
        task.resume()
    }
}
