//
//  ShowVC.swift
//  FoxPasswordGenerator
//
//  Created by Nirmal on 24/05/24.
//

import UIKit

class ShowVC: UIViewController {

    
    @IBOutlet weak var lbl_password: UILabel!
    
    @IBOutlet weak var btn_copy: UIButton!
    
    var password = ""
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        lbl_password.text = password
        btn_copy.LeafUP(btn: btn_copy)
     
    }
    
    @IBAction func btn_copy(_ sender: Any) {
        btn_copy.LeafUP(btn: btn_copy)
        guard let textToCopy = lbl_password.text else {
                    // No text to copy
                    return
                }
                
                UIPasteboard.general.string = textToCopy
                
                // Optional: Provide feedback to the user
                let alertController = UIAlertController(title: "Copied", message: "Text copied to clipboard!", preferredStyle: .alert)
                let okAction = UIAlertAction(title: "OK", style: .default, handler: nil)
                alertController.addAction(okAction)
                present(alertController, animated: true, completion: nil)
    }
    
    @IBAction func btn_back(_ sender: Any) {
        navigationController?.popViewController(animated: true)
    }
    

}
