//
//  HomeVC.swift
//  FoxPasswordGenerator
//
//  Created by Nirmal on 24/05/24.
//

import UIKit

class HomeVC: UIViewController {

    
    @IBOutlet weak var btn_start: UIButton!
    
    
   
    
    override func viewDidLoad() {
        super.viewDidLoad()
        navigationController?.navigationBar.isHidden = true
        btn_start.Button4X4(btn: btn_start, Redius: 20)
        btn_start.LeafUP(btn: btn_start)

    }
    
    @IBAction func btn_start(_ sender: Any) {
        
            let vc = self.storyboard?.instantiateViewController(withIdentifier: "GenerateVC") as! GenerateVC
            self.navigationController?.pushViewController(vc, animated: true)
        
    }
    
    

}
