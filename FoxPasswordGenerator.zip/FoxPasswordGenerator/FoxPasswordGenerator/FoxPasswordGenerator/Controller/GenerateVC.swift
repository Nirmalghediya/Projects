//
//  GenerateVC.swift
//  FoxPasswordGenerator
//
//  Created by Nirmal on 24/05/24.
//

import UIKit

class GenerateVC: UIViewController {

    @IBOutlet weak var txt_length: UITextField!
    
    
    @IBOutlet weak var btn_generate: UIButton!
   
    @IBOutlet weak var loader: UIActivityIndicatorView!
    
    @IBOutlet weak var lbl_message: UILabel!
    
    
 
    override func viewDidLoad() {
        super.viewDidLoad()
        loader.isHidden = true
        lbl_message.isHidden = true
        btn_generate.LeafUP(btn: btn_generate)
    }
    
    @IBAction func btn_generate(_ sender: Any) {
        btn_generate.LeafUP(btn: btn_generate)
        let len = txt_length.text
        let passlen = Int(len!)
        self.loader.isHidden = false
        self.loader.startAnimating()
        self.lbl_message.isHidden = false
        
        APIManager.shared.generatePassword(length: passlen!)  { password in
            if let password = password {
                print("Generated password: \(password)")
               
                DispatchQueue.main.asyncAfter(deadline: .now() + 3.0) {
                    self.lbl_message.text = "Generating Password..."
                        }
                DispatchQueue.main.asyncAfter(deadline: .now() + 8.0) {
                    self.loader.isHidden = true
                    self.loader.stopAnimating()
                    self.lbl_message.isHidden = true
                    let vc = self.storyboard?.instantiateViewController(withIdentifier: "ShowVC") as! ShowVC
                    vc.password = password
                    self.navigationController?.pushViewController(vc, animated: true)
                        }
            } else {
                print("Failed to generate password")
                self.loader.isHidden = true
                self.loader.stopAnimating()
                self.lbl_message.text = "Sorry,Something went wrong!"
            }
        }
    }
    
    @IBAction func btn_back(_ sender: Any) {
        navigationController?.popViewController(animated: true)
    }
    
}


